import com.hzy.excel.OprateExecel;
import org.junit.Test;
import org.eclipse.jdt.core.dom.CompilationUnit;

import java.io.File;
import java.util.ArrayList;


public class MyAnalysisTest {

    @Test
    public void OperateExcelTest() {
        // 待读取的所有文件的公有文件夹路径
        String sourceCodePath = "E:\\IDEAFile\\ASTParser\\demo2\\Class";

        /**
         * Designpattern-master
         * GeekQ-Tools-master
         * memoryoptimization-master
         * miaosha-master
         * threadandjuc-master
         * zookeeperDesign-master
         */
        // 文件名
        String excelName = "Designpattern-master";
        // 表格名
        String sheetName = "关系一";
        // 保存路径
        String savePath = "E:\\IDEAFile\\ASTParser\\DateSource\\Excel\\JavaParser\\relation";

        OprateExecel execel = new OprateExecel(excelName, sheetName, savePath);

        /**
         * 第一个参数是待修改的文件名
         */
        execel.CreateExc();

        /* 自定义Class类路径，获取该路径下所有待提取关系文件的文件名 */
        ArrayList<String> filePaths = null;
        try {
            filePaths = new FileList().DirAll(new File(sourceCodePath));
        } catch (Exception e) {
            e.printStackTrace();
        }

        DemoVisitor visitor = new DemoVisitor(execel);

        for (String filePath : filePaths) {
            /*System.out.println(filepath);*/

            CompilationUnit comp = JdtAstUtil.getCompilationUnit(filePath);

            comp.accept(visitor);
        }

        ArrayList<ArrayList<String>> arrays = visitor.getRelations();

        for (ArrayList<String> array : arrays) {
            System.out.println(array);
            execel.InsertRow(array);
        }

        System.out.println("创建完毕");
    }

    @Test
    public void OperateEntityExcelTest() {
        // 待读取的所有文件的公有文件夹路径
        String sourceCodePath = "E:\\IDEAFile\\ASTParser\\demo2\\Class";

        /**
         * Designpattern-master
         * GeekQ-Tools-master
         * memoryoptimization-master
         * miaosha-master
         * threadandjuc-master
         * zookeeperDesign-master
         */
        // 文件名
        String excelName = "miaosha-master";
        // 表格名
        String sheetName = "实体一";
        // 保存路径
        String savePath = "E:\\IDEAFile\\ASTParser\\DateSource\\Excel\\JavaParser\\entity";
        // 表格标题
        String[] title = new String[]{"实体", "属性"};

        OprateExecel execel = new OprateExecel(excelName, sheetName, savePath, title);

        /**
         * 第一个参数是待修改的文件名
         */
        execel.CreateExc();

        /* 自定义Class类路径，获取该路径下所有待提取关系文件的文件名 */
        ArrayList<String> filePaths = null;
        try {
            filePaths = new FileList().DirAll(new File(sourceCodePath));
        } catch (Exception e) {
            e.printStackTrace();
        }

        EntityVisitor visitor = new EntityVisitor(execel);

        for (String filePath : filePaths) {

            CompilationUnit comp = JdtAstUtil.getCompilationUnit(filePath);

            comp.accept(visitor);
        }

        ArrayList<ArrayList<String>> arrays = visitor.getEntities();

        for (ArrayList<String> array : arrays) {
            System.out.println(array);
            execel.InsertRowEntity(array);
        }

        System.out.println("创建完毕");
    }

}

import com.hzy.excel.OprateExecel;

//import org.eclipse.jdt.core.dom.ASTVisitor;
//import org.eclipse.jdt.core.dom.PackageDeclaration;
//import java.util.HashMap;

import org.eclipse.jdt.core.dom.*;
import java.util.*;

public class EntityVisitor extends ASTVisitor {

    private OprateExecel execel;

    private ArrayList<ArrayList<String>> entities = new ArrayList<>(); //实体列表

    public EntityVisitor(OprateExecel execel) {
        this.execel = execel;
    }

    /**
     * 包属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(PackageDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null)
            temp.put("包名", String.valueOf(node.getName()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        this.entities.add(
                new ArrayList<String>(
                        Arrays.asList(
                                temp.get("包名"),
                                String.valueOf(temp)
                        )
                ));
        return true;
    }

    /**
     * 类、接口属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(TypeDeclaration node) {

        HashMap<String, String> CIAttr = getCIInfo(node);

        String typename = String.valueOf(node.getName());

        this.entities.add(
                new ArrayList<String>(
                        Arrays.asList(
                                typename,
                                String.valueOf(CIAttr)
                        )
                )
        );

        return true;
    }

    /**
     * 域属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(FieldDeclaration node) {

        for (Object obj : node.fragments()) {

            HashMap<String, String> fieldAttr = getFieldInfo(node, obj);

            this.entities.add(
                    new ArrayList<String>(
                            Arrays.asList(
                                    fieldAttr.get("域名"),
                                    String.valueOf(fieldAttr)
                            )
                    )
            );

        }
        return true;
    }

    /**
     * 方法和方法参数构建关系
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(MethodDeclaration node) {

        HashMap<String, String> methodAttr = getMethodInfo(node);

        List<SingleVariableDeclaration> list = node.parameters();

        this.entities.add(
                new ArrayList<String>(
                        Arrays.asList(
                                methodAttr.get("方法名"),
                                String.valueOf(methodAttr)
                        )
                )
        );

        return true;
    }

    /**
     * 提取类、接口属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getCIInfo(TypeDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null) {
            if (!node.isInterface()) {
                temp.put("类名", String.valueOf(node.getName()));
                if (node.getSuperclassType() != null)
                    temp.put("父类", String.valueOf(node.getSuperclassType()));
            }
            else {
                temp.put("接口名", String.valueOf(node.getName()));
                if (node.getSuperclassType() != null)
                    temp.put("父接口", String.valueOf(node.getSuperclassType()));
            }
        }
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 提取域属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getFieldInfo(FieldDeclaration node, Object obj) {
        VariableDeclarationFragment v = (VariableDeclarationFragment) obj;
        HashMap<String, String> temp = new HashMap<String, String>();
        if (v.getName() != null)
            temp.put("域名", String.valueOf(v.getName()));
        if (node.getType() != null)
            temp.put("类型", String.valueOf(node.getType()));
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 提取方法属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getMethodInfo(MethodDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null)
            temp.put("方法名", String.valueOf(node.getName()));
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.parameters().size() > 0)
            temp.put("参数列表", String.valueOf(node.parameters()));
        if (node.getReturnType2() != null)
            temp.put("返回值类型", String.valueOf(node.getReturnType2()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 返回实体列表
     * @return ArrayList<ArrayList<String>>
     */
    public ArrayList<ArrayList<String>> getEntities() {
        return entities;
    }

}


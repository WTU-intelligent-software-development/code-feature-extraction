package com.hzy.excel;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class OprateExecel {

    // 文件名
    private String filename;
    // 表格名
    private String sheetName;
    // 保存路径
    private String savePath;

    /**
     * 表格头部信息
     */
    private String[] titles;


    /**
     * 当前最后一行所在行数
     */
    private int rownum = 0;

    /**
     * 创建的当前XSSFWorkbook对象
     */
    private XSSFWorkbook workbook = null;

    public OprateExecel(String savepath) {
        titles = new String[]{"实体","属性集", "关系", "实体", "属性集"};
        
        this.savePath = savepath;
    }

    public OprateExecel(String[] titles) {
        this.titles = titles;
    }

    public OprateExecel(String filename, String sheetName, String savePath) {
        this.filename = filename;
        this.sheetName = sheetName;
        this.savePath = savePath;
        titles = new String[]{"实体","属性集", "关系", "实体", "属性集"};
    }

    public OprateExecel(String filename, String sheetName, String savePath, String[] title) {
        this.filename = filename;
        this.sheetName = sheetName;
        this.savePath = savePath;
        this.titles = title;
    }

    /**
     * 创建一个Excel表格
     * @param sheetName ExcelSheet名称
     */
    public void CreateExc() {
        //创建excel文档
        XSSFWorkbook workbook = new XSSFWorkbook();
        //创建sheet
        XSSFSheet sheet = workbook.createSheet(sheetName);

        //创建首行
        XSSFRow firstrow = sheet.createRow(rownum++);
        int cellnum = 0;
        //把保存在titles中的各个列名，分别在row中创建cell
        for(String key : this.titles){
            XSSFCell cell = firstrow.createCell(cellnum++);
            cell.setCellValue(key);
        }

        //下面可以继续创建行
        try {
            //把excel写到要写的outputStream中
            OutputStream output = new FileOutputStream(this.savePath + "\\" + this.filename + ".xlsx");
            workbook.write(output);
            //最后关闭
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        this.filename = filename;
        this.workbook = workbook;
    }

    public void InsertRow(ArrayList<String> arr) {
        XSSFRow currentRow = workbook.getSheet("关系一").createRow(rownum++);
        currentRow.createCell(0).setCellValue(arr.get(0));
        currentRow.createCell(1).setCellValue(arr.get(1));
        currentRow.createCell(2).setCellValue(arr.get(2));
        currentRow.createCell(3).setCellValue(arr.get(3));
        currentRow.createCell(4).setCellValue(arr.get(4));
        try {
            OutputStream output = new FileOutputStream(this.savePath + "\\" + this.filename + ".xlsx");
            workbook.write(output);
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void InsertRowEntity(ArrayList<String> arr) {
        XSSFRow currentRow = workbook.getSheet(this.sheetName).createRow(rownum++);
        currentRow.createCell(0).setCellValue(arr.get(0));
        currentRow.createCell(1).setCellValue(arr.get(1));
        try {
            OutputStream output = new FileOutputStream(this.savePath + "\\" + this.filename + ".xlsx");
            workbook.write(output);
            output.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

public class JdtAstUtil {
    /**
     * get compilation unit of source code
     * 输入参数为需解析的Java源代码文件路径
     * @param javaFilePath
     * 返回值为该文件对应的CompilationUnit节点
     * @return CompilationUnit
     */
    public static CompilationUnit getCompilationUnit(String javaFilePath){
        byte[] input = null;
        try {
            BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(javaFilePath));
            input = new byte[bufferedInputStream.available()];
            bufferedInputStream.read(input);
            bufferedInputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ASTParser astParser = ASTParser.newParser(AST.JLS8); //设置Java语言规范版本
        astParser.setSource(new String(input).toCharArray());
        /**
         * K_COMPILATION_UNIT：编译单元，即一个Java文件
         * K_CLASS_BODY_DECLARATIONS：类的声明
         * K_EXPRESSION：单个表达式
         * K_STATEMENTS：语句块
         */
        astParser.setKind(ASTParser.K_COMPILATION_UNIT);
        CompilationUnit result = (CompilationUnit) (astParser.createAST(null));
        return result;
    }
}
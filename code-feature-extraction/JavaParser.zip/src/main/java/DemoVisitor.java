import com.hzy.excel.OprateExecel;

//import org.eclipse.jdt.core.dom.ASTVisitor;
//import org.eclipse.jdt.core.dom.PackageDeclaration;
//import java.util.HashMap;

import org.eclipse.jdt.core.dom.*;
import java.util.*;

public class DemoVisitor extends ASTVisitor {

    private OprateExecel execel;

    private ArrayList<ArrayList<String>> relations = new ArrayList<>(); //关系列表

    private ArrayList<ArrayList<String>> entities = new ArrayList<>(); //实体列表

    private HashMap<String, String> packageMap;

    public DemoVisitor(OprateExecel execel) {
        this.execel = execel;
    }

    /**
     * 包属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(PackageDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null)
            temp.put("包名", String.valueOf(node.getName()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        this.entities.add(
                new ArrayList<String>(
                    Arrays.asList(
                            packageMap.get("包名"),
                            String.valueOf(packageMap)
                    )
        ));
        packageMap = temp;
        return true;
    }

    /**
     * 类、接口属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(TypeDeclaration node) {

        HashMap<String, String> CIAttr = getCIInfo(node);

        String typename = String.valueOf(node.getName());

        /**
         * 包与类、接口的包含关系
         */
        relations.add(
                new ArrayList<String>(
                        Arrays.asList(
                                packageMap.get("包名"),
                                String.valueOf(packageMap),
                                "包含",
                                typename,
                                String.valueOf(CIAttr)
                        )
                )
        );

        /**
         * 类与类的继承关系
         */
        if (!node.isInterface() && node.getSuperclassType() != null) {
            relations.add(new ArrayList<String>(Arrays.asList(
                    typename, String.valueOf((CIAttr)),
                    "继承",
                    String.valueOf(node.getSuperclassType()), String.valueOf(getCIInfo(node.getSuperclassType().getAST().newTypeDeclaration()))
            )));
        }

        /**
         * 接口与接口的继承关系
         */
        List<Type> superinterfaces = Collections.singletonList(node.getSuperclassType());
        if (node.isInterface() && superinterfaces != null && superinterfaces.size() > 0) {
            for (Type superinterface : superinterfaces) {
                if (superinterface != null) {
                    relations.add(new ArrayList<String>(Arrays.asList(
                            typename,
                            String.valueOf((CIAttr)),
                            "继承",
                            String.valueOf(superinterface),
                            String.valueOf(getCIInfo(superinterface.getAST().newTypeDeclaration()))
                    )));
                }
            }
        }

        /**
         * 类、接口与域的包含关系
         */
        for (FieldDeclaration field : node.getFields()) {
            /* 域属性集提取 */
            for (Object obj : field.fragments()) {
                HashMap<String, String> fieldAttr = getFieldInfo(field, obj);
                relations.add(new ArrayList<String>(Arrays.asList(
                        typename,
                        String.valueOf(CIAttr),
                        "包含",
                        String.valueOf(fieldAttr.get("域名")),
                        String.valueOf(fieldAttr))));
            }
        }

        /**
         * 类、接口与方法的包含关系
         */
        for (MethodDeclaration method : node.getMethods()) {
            /**
             * 方法属性集提取
             */
            HashMap<String, String> methodAttr = getMethodInfo(method);
            relations.add(new ArrayList<String>(Arrays.asList(
                    typename,
                    String.valueOf(CIAttr),
                    "包含",
                    String.valueOf(methodAttr.get("方法名")),
                    String.valueOf(methodAttr))));
        }

        this.entities.add(
                new ArrayList<String>(
                        Arrays.asList(
                                typename,
                                String.valueOf(CIAttr)
                        )
                )
        );

        return true;
    }

    /**
     * 域属性集提取
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(FieldDeclaration node) {
        for (Object obj : node.fragments()) {

            HashMap<String, String> fieldAttr = getFieldInfo(node, obj);

            /**
             * 域与类、接口的类型关系
             */
            relations.add(new ArrayList<String>(Arrays.asList(
                    fieldAttr.get("域名"),
                    String.valueOf(fieldAttr),
                    "类型是",
                    fieldAttr.get("类型"),
                    String.valueOf(getCIInfo(node.getType().getAST().newTypeDeclaration())))));

            this.entities.add(
                    new ArrayList<String>(
                            Arrays.asList(
                                    fieldAttr.get("域名"),
                                    String.valueOf(fieldAttr)
                            )
                    )
            );
        }
        return true;
    }

    /**
     * 方法和方法参数构建关系
     * @param node
     * @return boolean
     */
    @Override
    public boolean visit(MethodDeclaration node) {

        HashMap<String, String> methodAttr = getMethodInfo(node);

        List<SingleVariableDeclaration> list = node.parameters();

        for (SingleVariableDeclaration type : list) {

            VariableDeclaration v = (VariableDeclaration)type;

            /**
             * 域与参数列表类型的关系
             */
            relations.add(new ArrayList<String>(Arrays.asList(
                    methodAttr.get("方法名"),
                    String.valueOf(methodAttr),
                    "方法参数类型是",
                    String.valueOf(type.getType()),
                    String.valueOf(getCIInfo(type.getType().getAST().newTypeDeclaration()))
            )));

            /**
             * 方法与类、接口的返回值关系
             */
            if (node.getReturnType2() != null) {
                relations.add(new ArrayList<String>(Arrays.asList(
                        methodAttr.get("方法名"), String.valueOf(methodAttr),
                        "返回值是",
                        String.valueOf(node.getReturnType2()), String.valueOf(getCIInfo(node.getReturnType2().getAST().newTypeDeclaration()))
                )));
            }

        }

        this.entities.add(
                new ArrayList<String>(
                        Arrays.asList(
                                methodAttr.get("方法名"),
                                String.valueOf(methodAttr)
                        )
                )
        );

        return true;
    }

    /**
     * 提取类、接口属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getCIInfo(TypeDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null) {
            if (!node.isInterface()) {
                temp.put("类名", String.valueOf(node.getName()));
                if (node.getSuperclassType() != null)
                    temp.put("父类", String.valueOf(node.getSuperclassType()));
            }
            else {
                temp.put("接口名", String.valueOf(node.getName()));
                if (node.getSuperclassType() != null)
                    temp.put("父接口", String.valueOf(node.getSuperclassType()));
            }
        }
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 提取域属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getFieldInfo(FieldDeclaration node, Object obj) {
        VariableDeclarationFragment v = (VariableDeclarationFragment) obj;
        HashMap<String, String> temp = new HashMap<String, String>();
        if (v.getName() != null)
            temp.put("域名", String.valueOf(v.getName()));
        if (node.getType() != null)
            temp.put("类型", String.valueOf(node.getType()));
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 提取方法属性信息
     * @param node
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getMethodInfo(MethodDeclaration node) {
        HashMap<String, String> temp = new HashMap<String, String>();
        if (node.getName() != null)
            temp.put("方法名", String.valueOf(node.getName()));
        if (node.modifiers().size() > 0)
            temp.put("修饰符", String.valueOf(node.modifiers()));
        if (node.parameters().size() > 0)
            temp.put("参数列表", String.valueOf(node.parameters()));
        if (node.getReturnType2() != null)
            temp.put("返回值类型", String.valueOf(node.getReturnType2()));
        if (node.getJavadoc() != null)
            temp.put("注释", String.valueOf(node.getJavadoc()));
        return temp;
    }

    /**
     * 返回关系列表
     * @return ArrayList<ArrayList<String>>
     */
    public ArrayList<ArrayList<String>> getRelations() {
        return relations;
    }

    /**
     * 返回实体列表
     * @return ArrayList<ArrayList<String>>
     */
    public ArrayList<ArrayList<String>> getEntities() {
        return entities;
    }

}

